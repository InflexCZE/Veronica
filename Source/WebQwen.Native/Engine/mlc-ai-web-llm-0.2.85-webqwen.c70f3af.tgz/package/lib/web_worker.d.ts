import { ChatOptions } from "./config";
import { LogitProcessor } from "./types";
import { ChatCompletionChunk, Completion } from "./openai_api_protocols/index";
import { MessageContent } from "./message";
import { MLCEngine } from "./engine";
/**
 * Worker handler that can be used in a WebWorker
 *
 * @example
 *
 * // setup a chat worker handler that routes
 * // requests to the chat
 * const engine = new MLCEngine();
 * cont handler = new WebWorkerMLCEngineHandler(engine);
 * onmessage = handler.onmessage;
 */
export declare class WebWorkerMLCEngineHandler {
    /**
     * The modelId and chatOpts that the underlying engine (backend) is currently loaded with.
     * An engine can be loaded with multiple models, so modelId and chatOpts are lists.
     *
     * TODO(webllm-team): This is always in-sync with `this.engine` unless device is lost due to
     * unexpected reason. Therefore, we should get it from `this.engine` directly and make handler
     * stateless. Besides, consider if we should add appConfig, or use engine's API to find the
     * corresponding model record rather than relying on just the modelId.
     */
    modelId?: string[];
    chatOpts?: ChatOptions[];
    engine: MLCEngine;
    /** ChatCompletion and Completion share the same chunk generator. Each loaded model has its own. */
    protected loadedModelIdToAsyncGenerator: Map<string, AsyncGenerator<ChatCompletionChunk | Completion, void, void>>;
    /**
     * @param engine A concrete implementation of MLCEngineInterface
     */
    constructor();
    postMessage(msg: any): void;
    setLogitProcessorRegistry(logitProcessorRegistry?: Map<string, LogitProcessor>): void;
    handleTask<T extends MessageContent>(uuid: string, task: () => Promise<T>): Promise<void>;
    onmessage(event: any, onComplete?: (value: any) => void, onError?: () => void): void;
    /** Check whether frontend expectation matches with backend (modelId and chatOpts). If not (due
     * to possibly killed service worker), we reload here.
     * For more, see https://github.com/mlc-ai/web-llm/pull/533
     */
    reloadIfUnmatched(expectedModelId: string[], expectedChatOpts?: ChatOptions[]): Promise<void>;
}
export { ChatWorker, CreateWebWorkerMLCEngine, WebWorkerMLCEngine, } from "./worker_proxy";
//# sourceMappingURL=web_worker.d.ts.map