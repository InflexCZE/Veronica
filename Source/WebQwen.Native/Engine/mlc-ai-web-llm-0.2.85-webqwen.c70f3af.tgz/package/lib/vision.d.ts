/**
 * The Qwen3-VL vision tower on borrowed weight records
 * (docs/qwen38/S23-vision-tower.md, S40-bonsai-vision.md).
 *
 * The converter places every vision weight and the activation range in
 * named text-model records the text model does not read while an image is
 * encoded (`vision_config.borrow`). A request lends their arenas, uploads
 * the weights at their planned offsets, places every activation, including
 * a second VM's constant pool, in the activation range, and restores each
 * borrowed record from its host copy before the text model runs again.
 */
import * as tvmjs from "@mlc-ai/web-runtime";
export interface VisionContainer {
    name: string;
    shard: string;
    byte_offset: number;
    bytes: number;
    /** End of the weights placed in it (4-byte aligned). */
    extent: number;
}
export interface VisionBorrow {
    align: number;
    containers: Array<VisionContainer>;
    activations: {
        container: number;
        offset: number;
        bytes: number;
        patches: number;
    };
    /** Record name -> [container index, byte offset]. */
    placement: Record<string, [number, number]>;
}
/** Text-model records the vision tower borrows; each needs a host copy. */
export declare function borrowedRecordNames(cfg: VisionConfig): Array<string>;
export interface VisionCap {
    fixed: number;
    per_patch: number;
    n_time: number;
    /** Largest first-fit top of one encode over every N <= top_patches. */
    top_bytes: number;
    top_patches: number;
}
export interface VisionConfig {
    hidden_size: number;
    num_heads: number;
    head_dim: number;
    intermediate_size: number;
    num_blocks: number;
    patch_size: number;
    spatial_merge_size: number;
    projection_dim: number;
    layer_norm_eps: number;
    image_mean: Array<number>;
    image_std: Array<number>;
    rope_theta: number;
    position_grid: number;
    cache: string;
    borrow: VisionBorrow;
    cap: VisionCap | null;
    start_token_id: number;
    end_token_id: number;
}
interface CacheRecord {
    name: string;
    shape: Array<number>;
    dtype: string;
    nbytes: number;
    byteOffset: number;
}
interface CacheShard {
    dataPath: string;
    nbytes: number;
    records: Array<CacheRecord>;
}
/**
 * The vision cache's shard list. The shards download with the text weights
 * (`cacheOnlyShards` of fetchTensorCache) and stay in the artifact cache;
 * an image request uploads them into the borrowed planes.
 */
export declare function visionShards(cache: tvmjs.ArtifactCacheTemplate, modelUrl: string, cfg: VisionConfig, signal?: AbortSignal): Promise<Array<CacheShard>>;
/** An image already at its encode size, RGB bytes row-major. */
export interface VisionImage {
    rgb: Uint8Array;
    height: number;
    width: number;
}
export interface VisionImageResult {
    embeddings: Uint16Array;
    tokens: number;
    gridH: number;
    gridW: number;
    patches: number;
    encodeMs: number;
    blockMs: Array<number>;
    ledger: tvmjs.LendScopeLedger;
    /** "check" mode: max |fused - ref| / max |ref| of the attention, per block. */
    attnRelErr?: Array<number>;
}
export interface VisionRequestResult {
    images: Array<VisionImageResult>;
    uploadMs: number;
    restoreMs: number;
    weightViewBytes: number;
    totalMs: number;
}
/**
 * Bench modes for the S23 gates; all but "block" need a library built with
 * WEBQWEN_VISION_ATTN_REF=1. "split" runs each block as its three debug
 * stages, "ref" with the materialized attention, "check" computes both
 * attentions from the same q, k, v and continues with the fused one.
 */
export interface VisionProbe {
    mode?: "block" | "split" | "ref" | "check";
}
/** Patch (row, column) of every merged-order index: windows, 2 x 2 inside. */
export declare function mergeOrder(gh: number, gw: number): [Int32Array, Int32Array];
/** f16 [N, 3 * p * p] patch rows, column c * p * p + ky * p + kx. */
export declare function im2col(img: VisionImage, cfg: VisionConfig): Uint16Array;
/** Bilinear with aligned corners, as ggml_interpolate; f32 [N, C] in merge order. */
export declare function interpolatePositions(table: Uint16Array, img: VisionImage, cfg: VisionConfig, f16ToFloat: (bits: number) => number): Float32Array;
/**
 * Vision rotary tables, f32 [N, head_dim / 2] each: pair k rotates (k,
 * k + head_dim / 2); the first quarter of the pairs by the patch row, the
 * rest by the column, the frequency restarting (ggml vision mode).
 */
export declare function rotaryTables(img: VisionImage, cfg: VisionConfig): [Float32Array, Float32Array];
/**
 * The 32-aligned encode size of an `h x w` image under a cap of `maxPatches`
 * (llama.cpp's smart resize: round, shrink to the cap, grow to 8 tokens).
 */
export declare function targetSize(h: number, w: number, maxPatches: number, minTokens?: number): [number, number];
/**
 * The patch cap of one image: N_max = min(N_mem, N_time, N_chunk), with
 * N_chunk keeping the image and its two wrapper tokens inside one prefill
 * chunk and N_mem the patch count the activation range is proven for
 * (docs/qwen38/S40: the range holds the encode's first-fit top up to it).
 */
export declare function maxPatches(cfg: VisionConfig, prefillChunkSize: number): number;
/**
 * Decode an image URL as RGB at its encode size: EXIF orientation applied,
 * no color conversion, alpha dropped (RGB as the canvas returns it), then
 * stretched to the 32-aligned smart-resize size with high-quality smoothing.
 */
export declare function decodeImage(url: string, maxPatchCount: number): Promise<VisionImage>;
export declare class VisionEncoder {
    private tvm;
    private device;
    readonly cfg: VisionConfig;
    private modelUrl;
    private cacheOptions;
    private cache?;
    private shards?;
    private lent;
    /** Bench: the next encode throws after this block, once. */
    failAfterBlock: number | null;
    constructor(tvm: tvmjs.Instance, device: tvmjs.DLDevice, cfg: VisionConfig, modelUrl: string, cacheOptions: tvmjs.TensorCacheAccessOptions);
    private scoped;
    /** True while the planes are lent; the text VM must not run. */
    isLent(): boolean;
    private artifactCache;
    private url;
    private fetchArrayBuffer;
    manifest(): Promise<Array<CacheShard>>;
    /**
     * Upload every vision record except the position table into a view at
     * its planned place in a lent container. Returns the views by record name
     * and the host copy of the position table.
     */
    private uploadWeights;
    private weightArray;
    private upload;
    /**
     * Encode images at their final sizes. Lends every borrowed record's arena
     * for the whole request and restores the records before returning, also
     * when the encode fails; a failing restore leaves the model unusable.
     */
    encode(images: Array<VisionImage>, f16ToFloat: (bits: number) => number, probe?: VisionProbe): Promise<VisionRequestResult>;
    private encodeOne;
}
export {};
//# sourceMappingURL=vision.d.ts.map