/**
 * The page side of a worker engine: WebWorkerMLCEngine and its factory,
 * without the engine, its runtime or the tokenizer (the `proxy` entry of the
 * package, docs/INTEGRATION.md).
 */
import { AppConfig, ChatOptions, MLCEngineConfig } from "./config";
import type { SlotDigest, SlotInfo } from "./llm_chat";
import { MLCEngineInterface, InitProgressCallback, LogLevel, TokenScore } from "./types";
import { ChatCompletionRequestBase, ChatCompletionRequestStreaming, ChatCompletionRequestNonStreaming, ChatCompletion, ChatCompletionChunk, Completion, CompletionCreateParamsNonStreaming, CompletionCreateParamsStreaming, CompletionCreateParamsBase, CreateEmbeddingResponse, EmbeddingCreateParams } from "./openai_api_protocols/index";
import * as API from "./openai_api_protocols/index";
import { MessageContent, WorkerRequest } from "./message";
export interface ChatWorker {
    onmessage: any;
    postMessage: (message: any) => void;
}
/**
 * Creates `WebWorkerMLCEngine`, a client that holds the same interface as `MLCEngine`.
 *
 * Equivalent to `new webllm.WebWorkerMLCEngine(worker).reload(...)`.
 *
 * @param worker The worker that holds the actual MLCEngine, initialized with `new Worker()`.
 * @param modelId model_id of the model to load, either string or string[]. When multiple models
 *   are provided, we load all models sequentially. Each modelId needs to either be in
 *   `webllm.prebuiltAppConfig`, or in `engineCOnfig.appConfig`.
 * @param engineConfig Optionally configures the engine, see `webllm.MLCEngineConfig` for more.
 * @param chatOpts Extra options to optionally override the `mlc-chat-config.json` of `modelId`.
 *   The size of which needs to match that of `modelId`; chatOpts[i] will be used for modelId[i].
 * @returns An initialized `WebLLM.WebWorkerMLCEngine` with `modelId` loaded.
 *
 * @note engineConfig.logitProcessorRegistry is ignored for `CreateWebWorkMLCEngine()`.
 */
export declare function CreateWebWorkerMLCEngine(worker: any, modelId: string | string[], engineConfig?: MLCEngineConfig, chatOpts?: ChatOptions | ChatOptions[]): Promise<WebWorkerMLCEngine>;
/**
 * A client of MLCEngine that exposes the same interface
 *
 * @example
 *
 * const chat = new webllm.WebWorkerMLCEngine(new Worker(
 *   new URL('./worker.ts', import.meta.url),
 *   {type: 'module'}
 * ));
 */
export declare class WebWorkerMLCEngine implements MLCEngineInterface {
    worker: ChatWorker;
    /** For chat.completions.create() */
    chat: API.Chat;
    /** For completions.create() */
    completions: API.Completions;
    /** For embeddings.create() */
    embeddings: API.Embeddings;
    /**
     * The modelId and chatOpts that the frontend expects the backend engine is currently loaded
     * with. Needed for service worker. It is the backend and handler's job to match up with the
     * expectation despite the web/service worker possibly being killed.
     * Since an engine can load multiple models, both modelId and chatOpts are lists.
     */
    modelId?: string[];
    chatOpts?: ChatOptions[];
    private initProgressCallback?;
    private pendingPromise;
    constructor(worker: ChatWorker, engineConfig?: MLCEngineConfig);
    setInitProgressCallback(initProgressCallback?: InitProgressCallback): void;
    getInitProgressCallback(): InitProgressCallback | undefined;
    setAppConfig(appConfig: AppConfig): void;
    setLogLevel(logLevel: LogLevel): void;
    protected getPromise<T extends MessageContent>(msg: WorkerRequest): Promise<T>;
    reload(modelId: string | string[], chatOpts?: ChatOptions | ChatOptions[]): Promise<void>;
    getMaxStorageBufferBindingSize(): Promise<number>;
    getGPUVendor(): Promise<string>;
    getMessage(slot: number, modelId?: string): Promise<string>;
    runtimeStatsText(modelId?: string): Promise<string>;
    interruptGenerate(): void;
    unload(): Promise<void>;
    resetChat(slot: number, keepStats?: boolean, modelId?: string): Promise<void>;
    allocateSlot(modelId?: string): Promise<number>;
    freeSlot(slot: number, modelId?: string): Promise<void>;
    benchSlotInfo(modelId?: string): Promise<SlotInfo>;
    benchSlotDigest(slot: number, modelId?: string): Promise<SlotDigest>;
    forwardTokensAndSample(slot: number, inputIds: Array<number>, isPrefill: boolean, modelId?: string): Promise<number>;
    forwardTokensAndScore(slot: number, inputIds: Array<number>, topK: number, activeVocabSize?: number, modelId?: string): Promise<TokenScore>;
    /**
     * Every time the generator is called, we post a message to the worker asking it to
     * decode one step, and we expect to receive a message of `ChatCompletionChunk` from
     * the worker which we yield. The last message is `void`, meaning the generator has nothing
     * to yield anymore.
     *
     * @param selectedModelId: The model of whose async generator to call next() to get next chunk.
     *   Needed because an engine can load multiple models.
     *
     * @note ChatCompletion and Completion share the same chunk generator.
     */
    asyncGenerate(selectedModelId: string): AsyncGenerator<ChatCompletionChunk | Completion, void, void>;
    chatCompletion(request: ChatCompletionRequestNonStreaming): Promise<ChatCompletion>;
    chatCompletion(request: ChatCompletionRequestStreaming): Promise<AsyncIterable<ChatCompletionChunk>>;
    chatCompletion(request: ChatCompletionRequestBase): Promise<AsyncIterable<ChatCompletionChunk> | ChatCompletion>;
    completion(request: CompletionCreateParamsNonStreaming): Promise<Completion>;
    completion(request: CompletionCreateParamsStreaming): Promise<AsyncIterable<Completion>>;
    completion(request: CompletionCreateParamsBase): Promise<AsyncIterable<Completion> | Completion>;
    embedding(request: EmbeddingCreateParams): Promise<CreateEmbeddingResponse>;
    onmessage(event: any): void;
}
//# sourceMappingURL=worker_proxy.d.ts.map