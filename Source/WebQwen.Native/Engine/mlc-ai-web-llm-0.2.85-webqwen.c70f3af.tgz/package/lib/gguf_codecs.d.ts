export interface HostPlane {
    dtype: string;
    shape: number[];
    bytes: Uint8Array;
}
export interface RowDecoder {
    readonly codec: string;
    readonly rows: number;
    readonly hidden: number;
    readonly planeBytes: number;
    decodeRowF32(row: number, out: Float32Array, outBase: number): void;
    decodeRowF16(row: number, out: Uint16Array, outBase: number): void;
}
export declare const HOST_DECODABLE_CODECS: readonly string[];
export declare function isHostDecodable(codec: string): boolean;
export declare const HADAMARD_BLOCK = 1024;
/**
 * The publisher's inverse Hadamard fold of the embedding (docs/qwen38/
 * S27-bonsai-ptq1_0.md, D8): a stored row z is restored as h = s * (H z) / 32
 * per 1024-wide block, H the natural-order Walsh-Hadamard matrix and s the
 * +-1 sign vector of the hidden width. The transform runs in f64 on the
 * inner decoder's f32 row; the result is rounded to f32 once, and
 * decodeRowF16 rounds that f32 to f16.
 */
export declare class InverseHadamardRowDecoder implements RowDecoder {
    readonly codec: string;
    readonly rows: number;
    readonly hidden: number;
    readonly planeBytes: number;
    private readonly inner;
    private readonly signs;
    private readonly raw;
    private readonly work;
    private scratch;
    constructor(inner: RowDecoder, signs: Float64Array);
    decodeRowF32(row: number, out: Float32Array, outBase: number): void;
    decodeRowF16(row: number, out: Uint16Array, outBase: number): void;
}
/** The +-1 vector of `model_config.hadamard.inverse_signs` (bit set = -1). */
export declare function parseInverseSigns(hex: string, width: number): Float64Array;
export declare function makeRowDecoder(codec: string, shape: number[], planes: Map<string, HostPlane>): RowDecoder;
//# sourceMappingURL=gguf_codecs.d.ts.map