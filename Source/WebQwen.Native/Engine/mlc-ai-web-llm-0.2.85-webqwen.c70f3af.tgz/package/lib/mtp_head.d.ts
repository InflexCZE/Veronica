/**
 * Host-side (wasm) MTP head body for Qwen3.5 / Qwen3.8.
 *
 * Everything of the nextn block except the final lm_head matmul: enorm/hnorm,
 * eh_proj, one gated-attention layer with its own KV cache, the SiLU MLP and
 * shared_head_norm. The caller supplies the main model's post-output_norm
 * hidden row and the already decoded embedding row of the candidate token, and
 * gets back the post-shared_head_norm row to feed to lm_head.
 *
 * The wasm module is built by toolchain/mtp/build.sh into lib/mtp/.
 */
export declare const MTP_SLOTS: readonly string[];
export declare const MTP_CODEC_IDS: {
    [codec: string]: number;
};
export interface MtpHeadConfig {
    n_embd: number;
    n_head: number;
    n_head_kv: number;
    head_dim: number;
    n_rot: number;
    n_ff: number;
    eps: number;
    rope_theta: number;
    attn_scale: number;
    /** MRoPE sections; kept for provenance, text-only positions reduce to 1-D rope. */
    rope_sections?: number[];
}
export interface MtpTensorRecord {
    name: string;
    codec: string;
    in: number;
    out: number;
    bytes: Uint8Array;
}
export interface MtpTimings {
    totalMs: number;
    matmulMs: number;
    attnMs: number;
    quantMs: number;
    steps: number;
    prefillTokens: number;
    bytesStreamed: number;
}
export interface MtpWasmModule {
    HEAPU8: Uint8Array;
    HEAP8: Int8Array;
    HEAP16: Int16Array;
    HEAP32: Int32Array;
    HEAPF32: Float32Array;
    HEAPF64: Float64Array;
    _malloc(n: number): number;
    _free(p: number): void;
    _mtp_init(nEmbd: number, nHead: number, nHeadKv: number, headDim: number, nRot: number, nFf: number, eps: number, ropeTheta: number, attnScale: number, maxCtx: number, nThreads: number): number;
    _mtp_set_tensor(slot: number, codec: number, data: number, nIn: number, nOut: number): number;
    _mtp_ready(): number;
    _mtp_forward(h: number, e: number, pos: number, nTok: number, out: number): number;
    _mtp_truncate(nKeep: number): number;
    _mtp_kv_len(): number;
    _mtp_reset_timers(): void;
    _mtp_get_timers(out: number): void;
    _mtp_threads(): number;
    _mtp_simd(): number;
    _mtp_chunk(): number;
    _mtp_selfcheck(rowsPerTensor: number, nTok: number, out: number): void;
    _mtp_vec_dot_probe(codec: number, n: number, w: number, act: number): number;
    _mtp_vec_dot_generic(codec: number, n: number, w: number, act: number): number;
    _mtp_quantize_probe(n: number, act: number, d: number, qs: number, bsums: number): void;
}
export interface MtpRecordFile {
    config: MtpHeadConfig & {
        block: number;
        source?: string;
    };
    tensors: MtpTensorRecord[];
}
/**
 * Parse the .mtp container written by toolchain/mtp/export_records.py. The
 * blobs are views into `bytes`, never copies.
 */
export declare function parseMtpRecords(bytes: Uint8Array): MtpRecordFile;
export interface MtpInitOptions {
    maxContext?: number;
    threads?: number;
}
/**
 * True when the page may hand a SharedArrayBuffer to a Worker, which is what
 * `pthread_create` needs. Without it the head still runs, on one thread.
 */
export declare function mtpCrossOriginIsolated(): boolean;
/**
 * Threads to ask for. One core is left to the page: the head runs on the main
 * thread while WebGPU is recording the next dispatches on it.
 */
export declare function mtpDefaultThreads(requested?: number): number;
/**
 * Where `mtp_head.mjs` is served from. It ships in the package at
 * `lib/mtp/mtp_head.mjs`, and emscripten finds its own `.wasm` and worker
 * script beside it, so this is the only path the host has to supply.
 *
 * It is not derived from `import.meta.url`: jest compiles this file to
 * CommonJS, where that is a syntax error, and the bench imports the bundle
 * from a `blob:` URL, which cannot be the base of a relative one. An explicit
 * absolute URL is the one thing that is right in every case.
 *
 *   webllm.setMtpModuleUrl(new URL("/assets/webllm/mtp/mtp_head.mjs", location.href).href)
 */
export declare function setMtpModuleUrl(url: string): void;
/** Instantiate the head's wasm module. */
export declare function loadMtpWasmModule(moduleUrl?: string): Promise<MtpWasmModule>;
export declare class MtpHead {
    private readonly mod;
    private config;
    private weightPtrs;
    private scratch;
    private timerPtr;
    constructor(mod: MtpWasmModule);
    /**
     * Upload the head weights and start the worker pool. `weights` must hold one
     * record per entry of MTP_SLOTS; order inside the array does not matter.
     */
    init(config: MtpHeadConfig, weights: MtpTensorRecord[], options?: MtpInitOptions): void;
    get threads(): number;
    /** True when the module was built with wasm SIMD128 kernels. */
    get simd(): boolean;
    /** Tokens per internal forward chunk; the weight set streams once per chunk. */
    get chunkTokens(): number;
    /**
     * Run the shipped kernels and ggml's generic reference over `rowsPerTensor`
     * rows of every loaded tensor and report how far apart they land. The
     * integer dot products are identical by construction, so a nonzero
     * difference here is f32 reduction order and nothing else.
     */
    selfcheck(rowsPerTensor?: number, nTok?: number): {
        compared: number;
        differing: number;
        worstAbs: number;
        refMaxAbs: number;
        worstRel: number;
    };
    get kvLength(): number;
    /** Append `positions.length` entries to the KV cache, streaming the weights once. */
    prefill(hiddenRows: Float32Array, tokenEmbRows: Float32Array, positions: Int32Array): Float32Array;
    /** One drafting position. */
    step(hiddenRow: Float32Array, tokenEmbRow: Float32Array, position: number): Float32Array;
    /** Drop KV entries above `nKeep`, for a rejected draft suffix. */
    truncate(nKeep: number): void;
    timings(): MtpTimings;
    resetTimings(): void;
    dispose(): void;
    private freeWeights;
    private ensureScratch;
    private forward;
}
//# sourceMappingURL=mtp_head.d.ts.map