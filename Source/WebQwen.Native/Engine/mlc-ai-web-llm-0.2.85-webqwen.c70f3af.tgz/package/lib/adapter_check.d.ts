/**
 * Whether a WebGPU adapter can run the libraries of this build
 * (docs/INTEGRATION.md 2d; docs/qwen38/S38-chat-contract.md step 9). The
 * requirements come from the dist manifest's model entries; with several
 * entries the strictest of each wins, so one check speaks for all of them.
 *
 * A failure carries a scope: "browser" when the browser hides what the build
 * needs (WebGPU without subgroups or the subgroup range fields: another
 * browser may run it), "machine" when the GPU or its driver lacks it.
 */
export interface AdapterRequirements {
    required_features: ReadonlyArray<string>;
    subgroup_min_size: number;
    subgroup_max_size: number;
    required_limits: {
        maxStorageBufferBindingSize: number;
        maxBufferSize: number;
    };
}
/** The members of a GPUAdapter the check reads. */
export interface AdapterLike {
    features: {
        has(name: string): boolean;
    };
    limits: {
        maxStorageBufferBindingSize: number;
        maxBufferSize: number;
    };
    info?: {
        vendor?: string;
        architecture?: string;
        description?: string;
        device?: string;
        subgroupMinSize?: unknown;
        subgroupMaxSize?: unknown;
    };
}
export type AdapterFailure = "missing-feature" | "no-subgroup-range" | "subgroup-range" | "buffer-limits";
export interface AdapterCheck {
    ok: boolean;
    /** One line describing the adapter as the check saw it. */
    description: string;
    failure?: AdapterFailure;
    scope?: "browser" | "machine";
    /** The feature that is missing (`missing-feature`). */
    feature?: string;
    error?: string;
}
/** The strictest requirement of several manifest entries. */
export declare function combineRequirements(entries: ReadonlyArray<AdapterRequirements>): AdapterRequirements;
/**
 * @param chromium Whether the browser is Chromium-based: a missing feature
 * there is the machine's, elsewhere the browser's.
 */
export declare function checkAdapter(adapter: AdapterLike, entries: AdapterRequirements | ReadonlyArray<AdapterRequirements>, chromium: boolean): AdapterCheck;
//# sourceMappingURL=adapter_check.d.ts.map