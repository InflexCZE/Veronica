/** An error as it crosses the worker boundary in a `throw` response. */
export interface SerializedError {
    name: string;
    message: string;
    stack?: string;
    /** The error's own data fields, primitives only. */
    fields: Record<string, string | number | boolean | null>;
}
export declare function serializeError(err: unknown): SerializedError;
export declare function deserializeError(serialized: SerializedError): Error;
//# sourceMappingURL=worker_error.d.ts.map