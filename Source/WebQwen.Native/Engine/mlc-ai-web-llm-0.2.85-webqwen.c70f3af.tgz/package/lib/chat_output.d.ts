/**
 * The model's reply split into OpenAI `reasoning_content`, `content` and
 * `tool_calls` (docs/qwen38/S38-chat-contract.md, D9, D10). Both template
 * families answer in the same format: reasoning closed by `</think>`, then
 * text and `<tool_call><function=NAME><parameter=K>value</parameter>...`
 * blocks (the `qwen3_coder` tool format).
 */
export interface ParsedToolCall {
    id: string;
    type: "function";
    function: {
        name: string;
        arguments: string;
    };
}
/** One step's output; empty fields are left out. */
export interface ReplyDelta {
    reasoning_content?: string;
    content?: string;
    tool_calls?: ParsedToolCall[];
}
/** A whole reply as the parser read it. */
export interface ParsedReply {
    content: string;
    reasoning_content: string;
    tool_calls: ParsedToolCall[];
}
/** The call's name and its arguments as a JSON object text, or null. */
export declare function parseCallBody(body: string, tools: ReadonlyArray<unknown>): {
    name: string;
    arguments: string;
} | null;
/**
 * Streaming reader of one reply. Text is pushed as it grows; a suffix that
 * may begin a tag or a stop string is held back until the next push
 * decides. A call is emitted whole when it closes; one still open at
 * `finish()` is emitted with its raw text as `arguments` (D10).
 */
export declare class ReplyParser {
    private readonly tools;
    private readonly stops;
    private state;
    private buffer;
    private pendingSpace;
    private afterThink;
    readonly reply: ParsedReply;
    /**
     * @param thinking Whether the generation prompt opened the think block.
     * @param tools The request's tools, for typing arguments.
     * @param stops Stop strings of the request, held back like tags.
     */
    constructor(thinking: boolean, tools?: ReadonlyArray<unknown>, stops?: ReadonlyArray<string>);
    push(text: string): ReplyDelta;
    finish(): ReplyDelta;
    private drain;
    private consumeThink;
    private consumeText;
    private consumeCall;
    /**
     * Trailing whitespace is held until text follows it: the template trims
     * content, and whitespace before a call or at the end is not content.
     */
    private emitText;
    private emitReasoning;
    private emitCall;
}
/** A whole reply at once. */
export declare function parseReply(text: string, thinking: boolean, tools?: ReadonlyArray<unknown>): ParsedReply;
//# sourceMappingURL=chat_output.d.ts.map