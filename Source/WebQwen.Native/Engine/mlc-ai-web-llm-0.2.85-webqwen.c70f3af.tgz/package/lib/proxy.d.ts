/**
 * `@mlc-ai/web-llm/proxy`: what a page needs to drive an engine that lives
 * in a worker, without the engine, its WebGPU runtime or the tokenizer
 * (docs/INTEGRATION.md). The worker script imports the full package.
 */
export { WebWorkerMLCEngine, CreateWebWorkerMLCEngine, ChatWorker, } from "./worker_proxy";
export { checkAdapter, combineRequirements, type AdapterCheck, type AdapterFailure, type AdapterLike, type AdapterRequirements, } from "./adapter_check";
export { ContextWindowSizeExceededError, UnknownSlotError, SlotsUnsupportedError, SlotSwapError, ChatTemplateError, InvalidToolChoiceError, } from "./error";
export { DEFAULT_CONTEXT_WINDOW_SIZE } from "./config";
export type { AppConfig, ChatOptions, MLCEngineConfig, ModelRecord, GenerationConfig, } from "./config";
export type { InitProgressCallback, InitProgressReport, MLCEngineInterface, } from "./types";
export { StopCause } from "./openai_api_protocols/index";
export type { ChatCompletionRequest, ChatCompletionRequestStreaming, ChatCompletionRequestNonStreaming, ChatCompletion, ChatCompletionChunk, ChatCompletionMessage, ChatCompletionMessageParam, ChatCompletionMessageToolCall, ChatCompletionTool, ChatCompletionContentPart, CompletionUsage, } from "./openai_api_protocols/index";
//# sourceMappingURL=proxy.d.ts.map