import { ChatConfig, ConvTemplateConfig } from "./config";
import { ChatCompletionContentPartImage, ChatCompletionRequest } from "./openai_api_protocols/index";
import { ChatTemplateName, TemplateMessage, TemplateOptions } from "./chat_template";
type ImageURL = ChatCompletionContentPartImage.ImageURL;
/**
 * The last reply this conversation's slot generated: the ids it emitted
 * (its last one is not forwarded when the reply did not end on the stop
 * token), the KV length when it began, and the closing a render of it ends
 * with (S38 D12), which the next reused prefill feeds after the ids not yet
 * in the KV.
 */
interface ReplyRecord {
    readonly kvStart: number;
    readonly ids: ReadonlyArray<number>;
    readonly closing: string;
}
/** What `Conversation.restore()` needs to undo the appends of one prefill. */
export interface ConversationSnapshot {
    readonly messageCount: number;
    readonly prompt: string | undefined;
    readonly replyOpen: boolean;
    readonly lastReply: ReplyRecord | undefined;
}
/** The family's renderer, or a load error naming the template. */
export declare function chatTemplateOf(config: ConvTemplateConfig): ChatTemplateName;
/**
 * One conversation as the model's template renders it: the request's
 * messages, the replies this engine produced, and the template options.
 */
export declare class Conversation {
    messages: TemplateMessage[];
    options: TemplateOptions;
    readonly config: ConvTemplateConfig;
    /** Whether the Conversation object is for text completion with no conversation-style formatting */
    isTextCompletion: boolean;
    /** Used when isTextCompletion is true */
    prompt: string | undefined;
    /** The generation prompt is part of the prompt; the reply is pending. */
    private replyOpen;
    private rawReplies;
    private lastReply;
    constructor(config: ConvTemplateConfig, isTextCompletion?: boolean);
    get template(): ChatTemplateName;
    snapshot(): ConversationSnapshot;
    /**
     * Back to a snapshot taken earlier. Only undoes appends: messages already
     * present at the snapshot are never modified in between.
     */
    restore(snapshot: ConversationSnapshot): void;
    private render;
    /** The whole conversation with its generation prompt. */
    getPromptArray(): Array<string | Array<string | ImageURL>>;
    /**
     * What follows the last reply this engine produced: its KV already holds
     * the history up to that reply.
     */
    getPromptArrayLastRound(): (string | (string | ChatCompletionContentPartImage.ImageURL)[])[];
    /**
     * Return prompt in an array for non-conversation text completion.
     */
    getPromptArrayTextCompletion(): Array<string>;
    /**
     * Resets all states for this.conversation.
     */
    reset(): void;
    getStopStr(): string[];
    getStopTokens(): number[];
    appendMessage(message: TemplateMessage): void;
    /** The generation prompt goes into the next prompt; a reply follows. */
    beginReply(): void;
    /**
     * The reply as generated; stored as its parse, the raw text beside it.
     * `ids` and `kvStart` (the KV length when the reply began) let the next
     * round reuse the KV; without them the next request prefills in full.
     */
    finishReply(message: string, ids?: ReadonlyArray<number>, kvStart?: number): void;
    /** The KV changed outside a chat round: the next request prefills in full. */
    forgetLastReply(): void;
    /**
     * Whether a KV of `filled` tokens holds this conversation up to its last
     * reply, all but the reply's ids not yet forwarded.
     */
    historyInKv(filled: number): boolean;
    /**
     * What a reused round prefills after a KV of `filled` tokens: the last
     * reply's ids not yet forwarded, its closing as a segment of its own, then
     * everything after the reply.
     */
    reusedPrefill(filled: number): {
        pending: number[];
        prompts: Array<string | Array<string | ImageURL>>;
    };
    /** The text a stored reply was parsed from. */
    rawReply(message: TemplateMessage): string | undefined;
}
export declare function getConversation(conv_template: ConvTemplateConfig, conv_config?: Partial<ConvTemplateConfig>, isTextCompletion?: boolean): Conversation;
export declare function messagesEqual(a: TemplateMessage, b: TemplateMessage): boolean;
/**
 * Whether `next` (a request's history) continues `old` (a slot's
 * conversation): the same options, and `old`'s messages, ending with a
 * finished reply, are the start of `next`'s.
 */
export declare function continuesConversation(old: Conversation, next: Conversation): boolean;
/**
 * Whether two conversations render the same prompt: the same messages
 * (assistant turns by parse equality) and the same template options.
 */
export declare function compareConversationObject(convA: Conversation, convB: Conversation): boolean;
/** The template options a chat completion request asks for. */
export declare function templateOptionsFromRequest(request: ChatCompletionRequest, config: ChatConfig): TemplateOptions;
/** A request message as the renderer takes it. */
export declare function templateMessage(message: ChatCompletionRequest["messages"][number]): TemplateMessage;
/**
 * Get a new Conversation object based on the chat completion request.
 *
 * @param request The incoming ChatCompletionRequest
 * @param includeLastMsg Include last message, by default is false. Set to true for testing only.
 * @note By default, `request.messages[-1]` is not included as it would be treated as a normal
 * input to `prefill()`.
 */
export declare function getConversationFromChatCompletionRequest(request: ChatCompletionRequest, config: ChatConfig, includeLastMsg?: boolean): Conversation;
export {};
//# sourceMappingURL=conversation.d.ts.map