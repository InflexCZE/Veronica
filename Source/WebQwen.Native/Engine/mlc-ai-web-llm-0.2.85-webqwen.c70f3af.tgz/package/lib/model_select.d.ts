/**
 * The loaded model a request names, or the only one loaded; throws when it
 * is ambiguous or missing.
 */
export declare function getModelIdToUse(loadedModelIds: string[], requestModel: string | undefined | null, requestName: string): string;
//# sourceMappingURL=model_select.d.ts.map