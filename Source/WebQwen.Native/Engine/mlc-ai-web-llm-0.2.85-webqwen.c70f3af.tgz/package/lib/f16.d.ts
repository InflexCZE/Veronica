/** float16 bit pattern to a JS number. */
export declare function f16ToFloat(bits: number): number;
/** JS number to a float16 bit pattern, round to nearest even. */
export declare function floatToF16(value: number): number;
//# sourceMappingURL=f16.d.ts.map