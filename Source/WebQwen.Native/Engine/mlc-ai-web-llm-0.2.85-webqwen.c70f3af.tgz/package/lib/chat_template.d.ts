/**
 * The models' own chat templates (docs/qwen38/S38-chat-contract.md),
 * hand-written per family and tested byte for byte against the shipped
 * Jinja `chat_template` rendered by transformers' `apply_chat_template`
 * (toolchain/chat/goldens.json).
 *
 * `qwen3_5`: Qwen3.5 (the 9B, the 2B). `qwen3_8`: Qwen3.8 (the 27B,
 * Ternary-Bonsai-2-27B). Both keep reasoning in history by default
 * (`preserve_thinking`), which the Qwen3.5 template does not have (S38 D7).
 */
import { ChatTemplateError } from "./error";
export type ChatTemplateName = "qwen3_5" | "qwen3_8";
export declare const CHAT_TEMPLATE_NAMES: ReadonlyArray<ChatTemplateName>;
export declare function isChatTemplateName(name: unknown): name is ChatTemplateName;
export type TemplateContentPart = {
    type: "text";
    text: string;
} | {
    type: "image_url";
    image_url: {
        url: string;
        detail?: string | null;
    };
} | {
    type?: string;
    [key: string]: unknown;
};
export interface TemplateToolCall {
    type?: string;
    id?: string;
    function?: {
        name: string;
        arguments?: unknown;
    };
    name?: string;
    arguments?: unknown;
}
export interface TemplateMessage {
    role: string;
    content?: string | TemplateContentPart[] | null;
    reasoning_content?: string | null;
    tool_calls?: TemplateToolCall[] | null;
    name?: string;
    tool_call_id?: string;
}
export interface TemplateOptions {
    tools?: ReadonlyArray<unknown> | null;
    enable_thinking?: boolean | null;
    reasoning_effort?: string | null;
    preserve_thinking?: boolean | null;
    add_generation_prompt?: boolean;
}
export interface PromptImage {
    image_url: string;
}
/** Rendered prompt: text runs and the images between them, in order. */
export type PromptPiece = string | PromptImage;
export { ChatTemplateError };
export declare const IMAGE_MARKER = "<|vision_start|><|image_pad|><|vision_end|>";
/**
 * A JSON value that keeps what a JS value loses and Python's rendering
 * shows: integer versus float literals and the order of integer-like keys.
 */
export type JsonNode = {
    kind: "object";
    entries: Array<[string, JsonNode]>;
} | {
    kind: "array";
    items: JsonNode[];
} | {
    kind: "string";
    value: string;
} | {
    kind: "number";
    text: string;
    isFloat: boolean;
} | {
    kind: "bool";
    value: boolean;
} | {
    kind: "null";
};
export declare class JsonLexError extends Error {
    constructor(message: string);
}
export declare function parseJsonNode(text: string): JsonNode;
/** A JS value as a node; a JS number is a float unless it is integral. */
export declare function toJsonNode(value: unknown): JsonNode;
/** Python's `repr(float)`: shortest round-trip digits, `.0` or exponent form. */
export declare function pythonFloatRepr(x: number): string;
/** transformers' `tojson`: `json.dumps` with `", "` / `": "`, unicode kept. */
export declare function pythonToJson(node: JsonNode): string;
export declare function piecesToText(pieces: ReadonlyArray<PromptPiece>): string;
/**
 * Render `messages` the way the family's template does. Throws
 * `ChatTemplateError` where the template raises.
 */
export declare function renderChatTemplate(name: ChatTemplateName, messages: ReadonlyArray<TemplateMessage>, options?: TemplateOptions): PromptPiece[];
//# sourceMappingURL=chat_template.d.ts.map