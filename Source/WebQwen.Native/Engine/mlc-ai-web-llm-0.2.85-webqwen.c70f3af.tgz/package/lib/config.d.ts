import { ResponseFormat } from "./openai_api_protocols";
import { LogitProcessor, InitProgressCallback, LogLevel } from "./types";
import { ModelIntegrity } from "./integrity";
/**
 * Conversation template config
 */
export interface ConvTemplateConfig {
    /** The chat template family the engine renders (`qwen3_5`, `qwen3_8`). */
    name?: string;
    system_template: string;
    system_message: string;
    roles: Record<Role, string>;
    role_templates?: Partial<Record<Role, string>>;
    seps: Array<string>;
    role_content_sep?: string;
    role_empty_sep?: string;
    stop_str: Array<string>;
    system_prefix_token_ids?: Array<number>;
    stop_token_ids: Array<number>;
    add_role_after_system_message?: boolean;
}
/**
 * Common vision model config fields. Model-specific fields are accessed
 * via the Record<string, unknown> extension.
 */
export type VisionModelConfig = {
    mm_tokens_per_image?: number;
    boi_token_index?: number;
    eoi_token_index?: number;
    vision_start_token_id?: number;
    vision_end_token_id?: number;
};
export declare enum Role {
    user = "user",
    assistant = "assistant",
    tool = "tool"
}
export declare const DefaultLogLevel: LogLevel;
/**
 * Place holders that can be used in role templates.
 * For example, a role template of
 * `<<question>> ${MessagePlaceholders.USER} <<function>> ${MessagePlaceholders.FUNCTION}`
 * will insert the user message to ${MessagePlaceholders.USER}
 * and insert the function message to ${MessagePlaceholders.FUNCTION}
 * at run time.
 */
export declare enum MessagePlaceholders {
    system = "{system_message}",
    user = "{user_message}",
    assistant = "{assistant_message}",
    tool = "{tool_message}",
    function = "{function_string}"
}
/**
 * Information about the tokenizer. Currently, only `token_postproc_method` is used to
 * post process the token table when using grammar.
 */
export interface TokenizerInfo {
    token_postproc_method: string;
    prepend_space_in_encode: boolean;
    strip_space_in_decode: boolean;
}
/**
 * Config of one chat model, a data structure representing `mlc-chat-config.json`.
 * This only corresponds to the chat-related fields and `tokenizer_files` of `mlc-chat-config.json`.
 * Only these fields affect the conversation in runtime.
 * i.e. The third part in https://llm.mlc.ai/docs/get_started/mlc_chat_config.html.
 *
 * This is initialized in `MLCEngine.reload()` with the model's `mlc-chat-config.json`.
 */
export interface ChatConfig {
    tokenizer_files: Array<string>;
    tokenizer_info?: TokenizerInfo;
    token_table_postproc_method?: string;
    vocab_size: number;
    conv_config?: Partial<ConvTemplateConfig>;
    conv_template: ConvTemplateConfig;
    context_window_size: number;
    sliding_window_size: number;
    attention_sink_size: number;
    max_history_size?: number;
    repetition_penalty: number;
    frequency_penalty: number;
    presence_penalty: number;
    top_p: number;
    temperature: number;
    bos_token_id?: number;
    model_type?: string;
    quantization?: string;
    model_config?: VisionModelConfig & Record<string, unknown>;
    /**
     * The model's default `reasoning_effort` (qwen3_8 templates), used when a
     * request sets none (docs/qwen38/S38-chat-contract.md, D6).
     */
    reasoning_effort?: string | null;
}
/**
 * Context window a model loads with when neither `ModelRecord.overrides` nor
 * `ChatOptions` sets `context_window_size`. A model whose own
 * `mlc-chat-config.json` is smaller keeps its own value; this only caps it.
 * Embedding models are exempt: their pipeline requires the window to equal
 * the compiled prefill chunk.
 * The KV cache is allocated for the whole window at load, so a larger window
 * is an opt-in that costs VRAM up front.
 */
export declare const DEFAULT_CONTEXT_WINDOW_SIZE = 20480;
/**
 * Custom options that can be used to override known config values.
 */
export interface ChatOptions extends Partial<ChatConfig> {
}
/**
 * Optional configurations for `CreateMLCEngine()` and `CreateWebWorkerMLCEngine()`.
 *
 * appConfig: Configure the app, including model list and persistent cache backend.
 * initProgressCallback: A callback for showing the progress of loading the model.
 * logitProcessorRegistry: A register for stateful logit processors, see `webllm.LogitProcessor`.
 *
 * @note All fields are optional, and `logitProcessorRegistry` is only used for `MLCEngine` and not
 * other `MLCEngine`s.
 */
export interface MLCEngineConfig {
    appConfig?: AppConfig;
    initProgressCallback?: InitProgressCallback;
    logitProcessorRegistry?: Map<string, LogitProcessor>;
    logLevel?: LogLevel;
}
/**
 * Config for a single generation.
 * Essentially `ChatConfig` without `tokenizer_files`, `conv_config`, or `conv_template`.
 * We also support additional fields not present in `mlc-chat-config.json` due to OpenAI-like APIs.
 *
 * Note that all values are optional. If unspecified, we use whatever values in `ChatConfig`
 * initialized during `MLCEngine.reload()`.
 * Values with numeric range checks also reject `NaN`.
 */
export interface GenerationConfig {
    repetition_penalty?: number | null;
    ignore_eos?: boolean;
    top_p?: number | null;
    temperature?: number | null;
    max_tokens?: number | null;
    frequency_penalty?: number | null;
    presence_penalty?: number | null;
    stop?: string | null | Array<string>;
    n?: number | null;
    logit_bias?: Record<string, number> | null;
    logprobs?: boolean | null;
    top_logprobs?: number | null;
    response_format?: ResponseFormat | null;
    enable_thinking?: boolean | null;
    enable_latency_breakdown?: boolean | null;
}
export declare function postInitAndCheckGenerationConfigValues(config: GenerationConfig): void;
export declare enum ModelType {
    "LLM" = 0,
    "embedding" = 1,
    "VLM" = 2
}
/**
 * Information for a model.
 * @param model: the huggingface link to download the model weights, accepting four formats:
 *    - https://huggingface.co/{USERNAME}/{MODEL}, which we automatically use the main branch
 *    - https://huggingface.co/{USERNAME}/{MODEL}/, which we automatically use the main branch
 *    - https://huggingface.co/{USERNAME}/{MODEL}/resolve/{BRANCH}
 *    - https://huggingface.co/{USERNAME}/{MODEL}/resolve/{BRANCH}/
 * @param model_id: what we call the model.
 * @param model_lib: link to the model library (wasm file) the model uses.
 * @param overrides: partial ChatConfig to override mlc-chat-config.json; can be used to change KVCache settings.
 * @param vram_required_MB: amount of vram in MB required to run the model (can use
 *    `utils/vram_requirements` to calculate).
 * @param low_resource_required: whether the model can run on limited devices (e.g. Android phone).
 * @param buffer_size_required_bytes: required `maxStorageBufferBindingSize`, different for each device.
 * @param required_features: feature needed to run this model (e.g. shader-f16).
 * @param model_type: the intended usecase for the model, if unspecified, default to LLM.
 * @param integrity: optional SRI hashes to verify downloaded artifacts. See {@link ModelIntegrity}.
 * @param host_embedding: keep the token embedding table in system memory and dequantize rows on
 *    the CPU (docs/PATCHES.md P8). Default true; the engine still keeps the table on the GPU when
 *    the model is tied, is an embedding model, or uses a codec the host decoder does not know.
 *    Set false to force the GPU path (A/B measurements). "verify" keeps both copies so
 *    `verifyHostEmbedding` can compare the host decoder against the `embed` kernel bit for bit.
 * @param mtp_head: opt in to multi-token prediction. `true` means the draft head is inside the
 *    model: its weights are shard records under "mtp." and its KV is one more layer of the paged
 *    cache, so there is nothing to fetch and the page needs no cross-origin isolation
 *    (docs/qwen38/M4-gpu-head.md). Absent means the model decodes one token at a time, which is
 *    also what happens when the library does not export the MTP entry points or when sampling is
 *    not greedy.
 * @param mtp_draft_length: how many tokens to draft per round. Default 3.
 * @param mtp_min_draft_prob: stop drafting when the head's own top-1 probability falls below
 *    this. Default 0.5.
 * @param host_ram_required_MB: system memory the load keeps for the persistent host copy of
 *    the output head (docs/qwen38/S39 D9); a load that cannot create it fails naming this.
 */
export interface ModelRecord {
    model: string;
    model_id: string;
    model_lib: string;
    overrides?: ChatOptions;
    vram_required_MB?: number;
    low_resource_required?: boolean;
    buffer_size_required_bytes?: number;
    required_features?: Array<string>;
    model_type?: ModelType;
    integrity?: ModelIntegrity;
    host_embedding?: boolean | "verify";
    mtp_head?: boolean;
    mtp_draft_length?: number;
    mtp_min_draft_prob?: number;
    host_ram_required_MB?: number;
}
/**
 * Extra configuration that can be
 * passed to the load.
 *
 * @param model_list: models to be used.
 * @param cacheBackend: the backend to use for caching models and other artifacts.
 * If unspecified, will use the Cache API. For more information, see:
 * https://developer.mozilla.org/en-US/docs/Web/API/Storage_API/Storage_quotas_and_eviction_criteria#what_technologies_store_data_in_the_browser
 * Supported values are:
 * - "cache": browser Cache API.
 * - "indexeddb": IndexedDB-backed cache.
 * - "cross-origin": Chrome Cross-Origin Storage extension-backed cache.
 * - "opfs": Origin Private File System-backed cache.
 *
 * @param opfsAccessMode: optional OPFS access mode. Only used when cacheBackend
 * is "opfs".
 * - "async": use async OPFS file APIs. This is the default.
 * - "sync": require OPFS sync access handles.
 * - "auto": use sync access handles when available and fall back to async OPFS otherwise.
 *
 * @note Note that the Cache API is the most well-tested in WebLLM as of now.
 */
export type CacheBackend = "cache" | "indexeddb" | "cross-origin" | "opfs";
export type OPFSAccessMode = "async" | "sync" | "auto";
export interface AppConfig {
    model_list: Array<ModelRecord>;
    cacheBackend?: CacheBackend;
    opfsAccessMode?: OPFSAccessMode;
}
export declare function getCacheBackend(appConfig: AppConfig): CacheBackend;
/**
 * modelVersion: the prebuilt model libraries that the current npm is compatible with, affects the
 * `model_lib`s in `prebuiltAppConfig`.
 *
 * @note The model version does not have to match the npm version, since not each npm update
 * requires an update of the model libraries.
 */
export declare const modelVersion = "v0_2_84/base";
export declare const modelLibURLPrefix = "https://raw.githubusercontent.com/mlc-ai/binary-mlc-llm-libs/main/web-llm-models/";
/**
 * Default models and model library mapping to be used if unspecified.
 *
 * @note This is the only source of truth of which prebuilt model libraries are compatible with the
 * current WebLLM npm version.
 */
export declare const prebuiltAppConfig: AppConfig;
//# sourceMappingURL=config.d.ts.map