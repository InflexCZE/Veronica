import * as tvmjs from "@mlc-ai/web-runtime";
import { Tokenizer } from "@mlc-ai/web-tokenizers";
import { ChatConfig, GenerationConfig, ModelRecord } from "./config";
import { VisionImage, VisionProbe, VisionRequestResult } from "./vision";
import { Conversation } from "./conversation";
import { TemplateMessage } from "./chat_template";
import { LogitProcessor, LatencyBreakdown, TokenScore, ForcedImage, BenchForwardResult, BenchForwardFn, BenchReadback, BenchPopNResult, BenchStateInfo, BenchVerifyCommitResult } from "./types";
import { ChatCompletionFinishReason, StopCause, ChatCompletionTokenLogprob } from "./openai_api_protocols/index";
export interface SlotInfo {
    slots: Array<number>;
    resident: number | null;
    stateBuffers: number;
    /** The first `kvBuffers` of the set are the KV cache's, in constructor order. */
    kvBuffers: number;
    hostBytes: number;
    lastSwap: SlotSwapTiming | null;
}
/** SHA-256 hex digests of one slot's context (`benchSlotDigest`). */
export interface SlotDigest {
    slot: number;
    resident: boolean;
    fresh: boolean;
    buffers: Array<string> | null;
    sizes: Array<number> | null;
    pendingRow: string | null;
    filledKVCacheLength: number;
    mtpGpuPrimed: boolean;
    conversation: string | null;
}
export interface SlotSwapTiming {
    outMs: number;
    inMs: number;
    hostBytes: number;
}
export declare const HOST_EMBED_PARAM = "model.embed_tokens";
export declare const HOST_EMBED_WEIGHT_NAME: string;
export declare const HOST_EMBED_SCALE_NAME: string;
export declare const HOST_PARAM_PREFIXES: string[];
export { f16ToFloat, floatToF16 } from "./f16";
export interface HostEmbeddingPlan {
    host: boolean;
    verify: boolean;
    reason: string;
    codec: string;
    planes: string[];
}
export interface HostEmbeddingCheck {
    tokens: number;
    hidden: number;
    bytes: number;
    hostHash: string;
    gpuHash: string;
    mismatches: number;
    firstMismatch?: {
        token: number;
        index: number;
        host: number;
        gpu: number;
    };
}
/**
 * Whether the token embedding table can stay in system memory for this model
 * and which records make it up. The decision is taken before the weights load
 * (the runtime diverts the records as they stream in) and the pipeline checks
 * afterwards that exactly those records arrived.
 *
 * A Hadamard-folded model stores its rows in the rotated basis and its library
 * has no `embed` (docs/qwen38/S27-bonsai-ptq1_0.md, D8): only the ggufmix host
 * decoder with the inverse rotation restores them, so any other plan is an
 * error here, before the weights stream in.
 */
export declare function hostEmbeddingPlan(config: ChatConfig, record: ModelRecord): HostEmbeddingPlan;
/**
 * Speculative decoding counters. `draftRatio` and `meanAcceptedLength` follow
 * llama.cpp's own definitions (`tools/server/server-context.cpp`): the ratio is
 * over every token proposed, and the mean length counts the bonus token that
 * every round emits whether or not anything was accepted.
 */
export type MtpStats = {
    enabled: boolean;
    disabledReason: string | null;
    draftLength: number;
    minDraftProb: number;
    rounds: number;
    draftedTokens: number;
    acceptedTokens: number;
    emittedTokens: number;
    acceptedPerPosition: Array<number>;
    /** Rounds that drafted nothing because the head's first token was under the cutoff. */
    emptyDrafts: number;
    /** Rounds whose draft length was cut so the round fits before the context wall. */
    wallCappedRounds: number;
    /** Rounds that committed fewer rows than they accepted, cut at a token that ended generation. */
    stopCutRounds: number;
    /** Rounds that sampled the verify rows rather than taking their argmax. */
    sampledRounds: number;
    /** Rounds by draft length: index k counts rounds that verified k drafts. */
    draftLengthCounts: Array<number>;
    headPrimedTokens: number;
    verifyMs: number;
    commitMs: number;
    hostMs: number;
    totalMs: number;
    prefillHeadMs: number;
    /** Whether the in-model head (M4) is enabled. */
    gpuHead: boolean;
    /** The drafting steps, each one head position plus its projection. */
    draftStepMs: number;
    /** `mtp_pending_hidden`, one tiny call a round. */
    pendingMs: number;
    /** Queue submits and device syncs inside the counted rounds. */
    submits: number;
    syncs: number;
};
/**
 * Bench only: sampled rows replayed on the host (penalties, softmax with
 * temperature, sort, top_p, the row's uniform) against the kernel's token.
 * A mismatch is a numeric tie when the uniform sits within `edge` of a CDF
 * boundary on the host.
 */
/** Bench (S29 B31): the head-of-sort sampler against the full sort. */
export type SamplerCheckStats = {
    rows: number;
    draws: number;
    mismatches: Array<{
        row: number;
        uniform: number;
        partial: number;
        full: number;
    }>;
    fallbacks: number;
    nucleusMax: number;
};
export type SampleReplayStats = {
    rows: number;
    mismatches: Array<{
        path: "plain" | "round";
        row: number;
        kernel: number;
        host: number;
        edge: number;
    }>;
};
/** A token's slice of a sampled row: [lo, hi) of the renormalized sorted CDF. */
export type SampledInterval = {
    rank: number;
    lo: number;
    hi: number;
};
/**
 * The first emitted token of a traced run that differs from the expected
 * sequence, described on the row it was drawn from (bench only).
 */
export type SampleDivergence = {
    index: number;
    uniform: number;
    token: number;
    expected: number;
    renorm: number;
    nucleus: number;
    own: SampledInterval | null;
    other: SampledInterval | null;
};
export declare class LLMChatPipeline {
    private config;
    private tokenizer;
    private tvm;
    private device;
    private vm;
    private prefill;
    private decoding;
    private verifying?;
    private mtpVerify?;
    private mtpCommit?;
    private prefillingToHidden?;
    private scoreTopk?;
    private resolvedModelABI;
    private kvStateKind;
    private image_embed;
    private vision?;
    private visionExported;
    private embed?;
    private fapplyBitmask;
    private fapplyPenalty;
    private fapplyLogitBias;
    private fsoftmaxWithTemperature;
    private fsampleWithTopP;
    private fsampleTopPPartial;
    private samplePartialFallbacks;
    private fargsortProbs;
    private fclearKVCaches;
    private fKVCacheAddSequence;
    private fKVCacheRemoveSequence;
    private fKVCacheBeginForward;
    private fKVCacheEndForward;
    private fKVCacheEnableSlidingWindowForSeq;
    private fKVCachePopN?;
    private fKVStateAddImage?;
    private fKVStateDebugMRoPEPosition?;
    private params;
    private kvCache?;
    private rnnState?;
    private fcreateKVCache?;
    private fcreateRNNState?;
    private stateSet?;
    private stateSetKvCount;
    private lastSwap?;
    private slots;
    private nextSlotId;
    private residentSlot?;
    private prefillLogitPositions?;
    private prefillLogitPositionHost;
    private maxHistorySize;
    private logitsOnCPU?;
    private filledKVCacheLength;
    /** The KV length when the current reply began (after its prompt). */
    private replyKvStart;
    private mtpDraftLength;
    private mtpMinDraftProb;
    private mtpDisabledReason;
    private mtpStats;
    private mtpDraftIdHost?;
    private mtpDraftProbHost?;
    private mtpForceOff;
    /** The first round of a session pays for the compiled pipelines; skip it. */
    private mtpWarmedUp;
    private mtpGpuFns;
    private mtpGpu;
    private mtpRowSamplers;
    private mtpVerifyRows?;
    private mtpSamplerRows;
    private commitPositionsDevice?;
    private penaltyDevice?;
    private logitBiasDevice?;
    private prefillInputIdsDevice?;
    private grammarBitmaskDevice?;
    private sampleExpect;
    private sampleEmitted;
    private sampleTrace;
    private sampleTraceRows;
    private sampleReplay;
    private samplerCheck;
    private sampleReplayRows;
    /** The target's post-final-norm row after the last committed token, on the
     * device. It is the head's companion for the next position it writes. */
    private mtpPendingRow?;
    private mtpIdsHost?;
    private mtpIndexDev?;
    private mtpIndexHost;
    private mtpGpuOptIn;
    /** Whether the prompt went through the head-carrying prefill. */
    private mtpGpuPrimed;
    private bosTokenId;
    private contextWindowSize;
    private slidingWindowSize;
    private attentionSinkSize;
    private prefillChunkSize;
    private compiledPrefillChunkSize;
    private resetStatsPerPrefill;
    private stopStr;
    private stopTokens;
    private outputMessage;
    private outputIds;
    private stopTriggered;
    private stopCause;
    private appearedTokensFreq;
    private imageDataCache;
    private visionImageCache;
    private visionEmbedCache;
    private conversation;
    private tokenLogprobArray;
    private decodingTotalTime;
    private decodingTotalTokens;
    private prefillTotalTime;
    private prefillTotalTokens;
    private curRoundDecodingTotalTokens;
    private curRoundPrefillTotalTokens;
    private curRoundDecodingTotalTime;
    private curRoundPrefillTotalTime;
    curRoundLatencyBreakdown: LatencyBreakdown;
    private logitProcessor?;
    private grammarMatcher?;
    private responseFormatCacheKey?;
    private xgTokenizerInfo?;
    private grammarCompiler?;
    private bitmaskSize;
    private fullVocabSize;
    private token_postproc_method;
    private prepend_space_in_encode;
    private curRoundGrammarInitTotalTime;
    private curRoundGrammarPerTokenTotalTime;
    private sampleIndices;
    private sampleIndicesDevice;
    private topPDevice;
    private decodeMaxDispatchesPerSubmit;
    private decodeMaxRecordMs;
    private hostEmbedding?;
    private hostEmbeddingOut?;
    private hostEmbeddingVerify;
    private singleEmbeddingDevice?;
    private prefillEmbeddingDevice?;
    private topPHost;
    private cachedTopP;
    private temperaturesDevice;
    private temperaturesHost;
    private cachedTemperature;
    private uniformSamplesDevice;
    private uniformSamplesHost;
    private sampledTokensHost;
    private singleTokenDevice;
    private singleTokenHost;
    constructor(tvm: tvmjs.Instance, tokenizer: Tokenizer, config: ChatConfig, logitProcessor?: LogitProcessor);
    dispose(): void;
    /**
     * Get the current message.
     */
    getMessage(): string;
    /**
     * Reset the runtime statistics
     */
    resetRuntimeStats(): void;
    /**
     * Reset the chat history
     */
    resetChat(keepStats?: boolean): void;
    /**
     * Reset KV Cache
     */
    resetKVCache(): void;
    allocateSlot(): number;
    /**
     * Run one state constructor inside a recording scope, or a replay of
     * `replay`, and return the scope's pointers.
     */
    private createInStateScope;
    freeSlot(id: number): void;
    /** Drop a slot's context; the resident slot is reset in place. */
    resetSlot(id: number, keepStats?: boolean): void;
    hasSlot(id: number): boolean;
    getResidentSlotId(): number | undefined;
    benchSlotInfo(): SlotInfo;
    /**
     * SHA-256 of a slot's context: the state set (read back when resident,
     * the host store when stored), the MTP companion row and the JS state.
     * A fresh slot has no context and reports null digests.
     */
    benchSlotDigest(id: number): Promise<SlotDigest>;
    /** Host bytes held by the stored slots. */
    getSlotHostBytes(): number;
    /**
     * Make `id` the resident slot, copying the resident one out first. Only
     * between requests: never between a BeginForward and its EndForward.
     */
    activateSlot(id: number): Promise<SlotSwapTiming>;
    private slotById;
    private disposeSlotObjects;
    private swapOutResident;
    private activateFreshSlot;
    private swapInStored;
    /**
     * @returns Whether stop is triggered.
     */
    stopped(): boolean;
    /**
     * @returns Finish reason; undefined if generation not started/stopped yet.
     */
    getFinishReason(): ChatCompletionFinishReason | undefined;
    /**
     * @returns Why generation stopped; undefined if generation not started/stopped yet.
     * Never `ToolCalls`: whether the output parses as tool calls is decided by the engine.
     */
    getStopCause(): StopCause | undefined;
    getFilledKVCacheLength(): number;
    getContextWindowSize(): number;
    /**
     * @returns tokenLogprobArray for this current round of autoregressive generation.
     * Updated upon each sampled token, cleared upon each prefillStep().
     */
    getTokenLogprobArray(): Array<ChatCompletionTokenLogprob>;
    /**
     * @returns the number of tokens decoded for a single request or a single choice in the request.
     */
    getCurRoundDecodingTotalTokens(): number;
    /**
     * @returns the number of tokens decoded for a single request or a single choice in the request.
     */
    getCurRoundPrefillTotalTokens(): number;
    /**
     * @returns the time spent on decode for a single request or a single choice in the request.
     */
    getCurRoundDecodingTotalTime(): number;
    /**
     * @returns the time spent on  for a single request or a single choice in the request.
     */
    getCurRoundPrefillTotalTime(): number;
    /**
     * @returns the time (seconds) spent on for initializing grammar matcher for a single request.
     */
    getCurRoundGrammarInitTotalTime(): number;
    /**
     * @returns the total time (seconds) spent on creating bitmask and accepting token grammar matcher
     * for all the generated tokens in a single request.
     */
    getCurRoundGrammarPerTokenTotalTime(): number;
    /**
     * @returns the breakdown of latencies for sampling each token for a single request.
     */
    getCurRoundLatencyBreakdown(): LatencyBreakdown;
    /**
     * @returns Runtime stats information.
     */
    runtimeStatsText(): string;
    /**
     * @returns Runtime stats information, starting from the last prefill performed.
     */
    curRoundRuntimeStatsText(): string;
    /**
     * @returns Prefill tokens per second, starting from the last prefill performed.
     */
    getCurRoundPrefillTokensPerSec(): number;
    /**
     * @returns Prefill tokens per second, starting from the last prefill performed.
     */
    getCurRoundDecodingTokensPerSec(): number;
    /**
     * Set the seed for the RNG `this.tvm.rng`.
     */
    setSeed(seed: number): void;
    private getResponseFormatKey;
    /**
     * @returns The conversation object (not a deep copy).
     */
    getConversationObject(): Conversation;
    /** Whether the KV holds the conversation up to its last reply (S38). */
    historyInKv(): boolean;
    /**
     * Set this.conversation to a new conversation object.
     */
    setConversation(newConv: Conversation): void;
    asyncLoadWebGPUPipelines(): Promise<void>;
    /**
     * Generate the first token given input prompt
     */
    /**
     * Set up the vision tower (docs/qwen38/S23) when the library exports it and
     * the config carries `model_config.vision_config`.
     */
    enableVision(modelUrl: string, cacheOptions: tvmjs.TensorCacheAccessOptions): boolean;
    hasVision(): boolean;
    /**
     * Encode every image of the prompt once, in prompt order, with both
     * planes lent for the whole batch and restored before the text model runs
     * (docs/qwen38/S23, "One request with images", steps 4-6).
     */
    private encodePromptImages;
    /**
     * The embedding rows of a prefill chunk holding images: token rows from
     * the host table, image rows from the vision tower. Each image's span is
     * recorded in the KV cache at its offset in the chunk, so the chunk's
     * forward gives its tokens 3-axis positions (docs/qwen38/S23).
     */
    private embedChunkWithImages;
    /**
     * Bench (S23 step 5): an image URL decoded and stretched exactly as a chat
     * request does, under this model's patch cap or `capOverride`.
     */
    benchDecodeImage(url: string, capOverride?: number): Promise<VisionImage & {
        maxPatches: number;
    }>;
    /** The vision cache files join the model download (cached, not loaded). */
    downloadVision(signal?: AbortSignal): Promise<void>;
    /** While the vision tower holds the lm_head planes no text call may run. */
    private assertTextUsable;
    /** Bench (S23 step 2): encode images at their final sizes, nothing else. */
    benchVisionEncode(images: Array<VisionImage>, probe?: VisionProbe): Promise<VisionRequestResult>;
    /** Bench (S23 gate e): sha-256 of a parameter tensor read back from the GPU. */
    benchParamDigest(name: string): Promise<{
        bytes: number;
        sha256: string;
    }>;
    /**
     * Prefill the request's last message (a chat conversation) or its prompt
     * (a text completion) and sample the first token.
     */
    prefillStep(inp: string | TemplateMessage, genConfig?: GenerationConfig): Promise<void>;
    setDecodeMaxDispatchesPerSubmit(maxDispatches: number): void;
    setDecodeMaxRecordMs(maxMs: number): void;
    setAllocAttribution(enable: boolean): void;
    takeAllocLedger(): tvmjs.AllocLedgerEntry[];
    setGPUProfiling(enable: boolean): void;
    takeGPUProfile(): tvmjs.GPUProfile;
    setDispatchTrace(enable: boolean, maxBytes?: number): void;
    getBindGroupCacheSizes(): {
        total: number;
        perKernel: Record<string, number>;
    };
    takeDispatchTrace(): Promise<tvmjs.DispatchTrace | null>;
    getShaderSources(): Record<string, string>;
    decodeStep(genConfig?: GenerationConfig): Promise<void>;
    /**
     * Manually trigger stop if it is not stopped.
     */
    triggerStop(): void;
    /**
     * Add a generated token and check for stop.
     *
     * @param nextToken The next token.
     * @param genConfig Configs that override `this.config` for this round of generation.
     */
    private processNextToken;
    /**
     * Run tokens through the stop conditions that depend on the tokens alone
     * (stop token, stop string, max_tokens) without changing any state. The
     * scan ends at the first token that stops generation, so a speculative
     * round learns how many of its tokens to commit before it commits them.
     *
     * @param tokens At least one token, in the order they were generated.
     * @param genConfig Configs that override `this.config` for this round of generation.
     */
    private scanTokens;
    /**
     * Apply a scan whose tokens are all in the KV cache but the last, and check
     * the one stop condition that depends on the cache: the context wall.
     */
    private applyTokens;
    /**
     * Set up host-side token embedding if the embedding table was kept off the
     * GPU. The engine decided that before the weights loaded (hostEmbeddingPlan)
     * and the runtime diverted the records; this builds the row decoder over
     * them. A diverted record without a decoder is an error, never a fallback:
     * the GPU path would run the `embed` kernel on the one-element placeholders.
     */
    private initHostEmbedding;
    /**
     * Dequantize the rows of the embedding table for `inputTokens` into
     * `hostEmbeddingOut` as float16 bit patterns.
     */
    private dequantizeEmbeddingRows;
    /** Set by the engine when the model record asked for "verify". */
    setHostEmbeddingVerify(enable: boolean): void;
    /**
     * Compare the host decoder against the model's `embed` kernel on the same
     * token ids, byte for byte. Needs `host_embedding: "verify"` in the model
     * record, which keeps the device copy of the table; otherwise the kernel
     * would read the one-element placeholders.
     */
    verifyHostEmbedding(inputTokens: number[]): Promise<HostEmbeddingCheck>;
    private embedTokensOnHost;
    /**
     * Given input tokens, return embeddings of them by calling embed kernel.
     *
     * @note precondition: inputTokens.length <= prefillChunkSize, since we take care of
     * chunking in `getChunkedPrefillInputData()`.
     */
    private getTokensEmbeddings;
    /**
     * Compute the number of embedding tokens an image will produce.
     * Must match the model's image_embed output size.
     * Based on mlc_llm/serve/data.py _compute_embed_size.
     */
    private computeImageEmbedSize;
    /**
     * Calculate resize dimensions per model type.
     * Based on vlm_utils.cc CalculateResizeShape
     */
    private calculateResizeShape;
    /**
     * Calculate crop dimensions per model type.
     * Based on vlm_utils.cc CalculateCropShape / CalculatePadShape
     */
    private calculateCropShape;
    /**
     * Embed an image input.
     */
    private getImageEmbeddings;
    /**
     * Embed and forward input data, that can be either array of tokens, or an image.
     * This will increment `this.filledKVCacheLength`.
     *
     * @param inputData data to embed and forward
     * @param inputDataLen length of this inputData, should smaller than prefill chunk size.
     * @returns The logits returned by this forward as tvmjs.Tensor on GPU.
     *
     * @note Precondition: inputData's data length is smaller than prefill chunk size
     */
    private embedAndForward;
    private static loadVMFunctionRegistry;
    private static getRequiredVMFunctionByName;
    private static getVMFunctionAvailability;
    private parseKVStateKind;
    private static resolveModelABI;
    private requireKVCache;
    private requireRNNState;
    private getSingleStateForABI;
    private getActiveKVStates;
    private invokePrefill;
    private invokeDecode;
    private invokeVerify;
    private invokeMtpVerify;
    private invokePrefillToHidden;
    /** Host-side argmax per position of a [1, n, vocab] float32 logits array. */
    private static argmaxRows;
    /**
     * One forward pass of `tokenIds` through the chosen compiled entry point,
     * with the logits dropped instead of sampled or read back. Measurement hook
     * for the MTP evaluation (docs/qwen38/MTP-phase0.md): it advances the KV
     * cache and the RNN state exactly as the production path does, so a caller
     * that repeats it must roll the state back itself (`benchPopN`) or re-prefill.
     *
     * @param tokenIds tokens to forward, at most `prefillChunkSize` of them.
     * @param fn which compiled function to call. `decode` requires a single token.
     * @param readback what to copy back to the host after the sync, timed apart
     *   from the forward. `ids` gives the greedy id of every position carried.
     * @returns wall milliseconds from before the embedding to after `device.sync()`,
     *   the sequence length before and after, and the shape of the first output
     *   (logits, or the int32 ids of `mtp_verify`).
     */
    benchForward(tokenIds: Array<number>, fn: BenchForwardFn, readback?: BenchReadback): Promise<BenchForwardResult>;
    /**
     * One speculative round: `mtp_verify` over `tokenIds`, `mtp_commit` of the
     * first `commitLen` of them, and the KV trim that drops the rest.
     *
     * The stash never leaves the GPU and never leaves this scope, which is why
     * the two calls are one method: the tensors `mtp_verify` returns are what
     * `mtp_commit` reads, and closing the scope frees them.
     *
     * @param tokenIds the tokens to verify, one small draft.
     * @param commitLen how many leading tokens to accept, 0 to `tokenIds.length`.
     *   At 0 nothing is committed, because the verification wrote no state.
     * @param readback `ids` reads the per-position greedy ids back, `ids_hidden`
     *   also reads the post-final-norm hidden rows.
     */
    benchVerifyCommit(tokenIds: Array<number>, commitLen: number, readback?: BenchReadback): Promise<BenchVerifyCommitResult>;
    /**
     * Roll one of the two states back by `n` positions through
     * `vm.builtin.kv_state_popn`. Reports the runtime's own error text instead of
     * throwing, since which of these succeed is the finding (MTP phase 0).
     */
    benchPopN(n: number, target: "kv_cache" | "rnn_state"): BenchPopNResult;
    /**
     * Book-keeping for a measurement loop that pops the KV cache: the pipeline's
     * own position counter is not touched by `benchPopN`, since the runtime call
     * knows nothing about it.
     */
    benchSetFilledLength(length: number): void;
    /**
     * Bench (S23 step 3): the KV runtime's image spans.
     *
     * - `grids`: per [gh, gw], `p0` text tokens, an image and `tail` text
     *   tokens are appended as bookkeeping only (begin and end forward, no
     *   model call, chunks of at most the prefill chunk size). Each forward's
     *   (t, h, w) map is checked against llama.cpp's rule.
     * - Pops, on the last grid: one ending inside the image must fail and
     *   leave the sequence as it was; one ending at the image start must drop
     *   the image, so the next token is at p0 again and 1-D.
     * - `tokens` (optional): prefilled in two chunks split at `split`, then one
     *   decode of `decodeToken`, twice: as is, and with a 1 x 1 image recorded
     *   on the first token of the second chunk, which sends that forward
     *   through the M-RoPE kernel with t = h = w. Both runs' logits must be
     *   identical to the bit.
     *
     * The chat is reset before and after.
     */
    benchMRoPE(opts: {
        grids: Array<[number, number]>;
        p0: number;
        tail: number;
        tokens?: Array<number>;
        split?: number;
        decodeToken?: number;
    }): Promise<any>;
    /** One forward through the production entry point; sha-256 of its f32 logits. */
    private benchLogitsDigest;
    /**
     * Chunk later prefills at `cap` tokens instead of the compiled chunk size;
     * `null` restores it. Only lowers the chunk: the KV cache, the memory plan
     * and the embedding staging buffer stay sized at the compiled value.
     */
    benchSetPrefillChunkCap(cap: number | null): number;
    benchState(): BenchStateInfo;
    private static emptyMtpStats;
    /**
     * Whether a request may take a speculative round. Temperature, top_p and
     * the penalties do not matter: the sampled round draws every verify row
     * with them (`mtpSampling`). What stays out is anything the round does not
     * reproduce per row: logit_bias, logprobs, a grammar, a logit processor.
     */
    private mtpGate;
    /** Temperature, top_p and penalties of a request, defaulted from the model config. */
    private resolveSampling;
    /**
     * The sampler a speculative round has to reproduce, or null for the greedy
     * round. Greedy is what the softmax kernel treats as argmax (temperature
     * at or below 1e-5) on unpenalized logits; a penalty changes which token is
     * the argmax, so a penalized request at temperature 0 is sampled too.
     */
    private mtpSampling;
    /** Whether the next decode step will take the speculative path. */
    mtpActive(genConfig?: GenerationConfig): boolean;
    getMtpStats(): MtpStats;
    resetMtpStats(): void;
    /** One speculative round of a request, its tokens applied to the conversation. */
    private mtpDecodeRound;
    /**
     * The tokens a verification emits: the accepted drafts and the target's own
     * token after them, cut at a token that ends generation. The round commits
     * exactly these, so the cut has to come before the commit: the recurrent
     * state cannot give rows back.
     *
     * @param ids The verification's argmax per row.
     * @param genConfig As for `mtpRoundGpu`.
     */
    private mtpEmitted;
    /**
     * How many tokens the next round may draft. A round writes its drafts and
     * then draft + 1 verified rows into the paged KV cache, which holds exactly
     * contextWindowSize positions, so near the wall it drafts only what still
     * fits and lands on the wall exactly.
     */
    private mtpRoundDraftLength;
    /** Whether the next round can take the in-model head. */
    private get mtpGpuReady();
    /**
     * Opt a model into the in-model head. There is nothing to fetch and no
     * cross-origin isolation to check: the only conditions are that the library
     * was built with the head and that a rejected tail can be rolled back.
     */
    enableMtpGpuHead(record: ModelRecord): void;
    /** The model's hidden width, which the head's rows and eh_proj are built on. */
    private mtpHiddenSize;
    /**
     * The device tensors a round holds across its calls. The pending row starts
     * at zero, which is the hidden state llama.cpp pairs with the first prompt
     * token; nothing reads the head's output for that row.
     */
    private mtpEnsureGpuScratch;
    /** Reset the head's companion row to the zero one a fresh sequence starts from. */
    private mtpResetGpuPending;
    /** Prompt prefill with the head primed inside the same forward, chunk by chunk. */
    private mtpPrefillChunksGpu;
    /**
     * The sampler kernels' rule recomputed on the host in f64: penalties as
     * `apply_penalty_inplace` (subtract presence plus count x frequency, then
     * divide a positive or multiply a negative logit by the repetition
     * penalty), `softmax_with_temperature` (argmax at or below 1e-5), sort,
     * then `sample_with_top_p`. Returns the token and the uniform's distance to
     * the nearest boundary of its slice, which bounds how far f32 rounding on
     * the device could move the draw.
     */
    private static hostSample;
    /**
     * Bench (S29 B31): draw the row again through `sample_top_p_partial` and
     * through argsort_probs + sample_with_top_p, for uniforms at and one f32
     * step beside each slice edge of the nucleus (host cumulative sum) and
     * `extra` more from a fixed generator; a partial token other than -1 has to
     * equal the full one. The request's uniform and RNG are left as they were.
     */
    private samplerCheckRow;
    /** Bench replay: check one sampled row's kernel token against the host's. */
    private replayRow;
    /**
     * Where `token` and `expected` sit in one sampled row, by the rule of
     * `sample_with_top_p`: the nucleus runs through the first sorted position
     * whose cumulative probability reaches top_p, R is the cumulative sum
     * there, and the token at sorted position j is drawn for u in
     * [C(j-1)/R, C(j)/R).
     */
    private static describeSampledRow;
    /** Bench trace: count an emitted token and describe it if it is the first to differ. */
    private traceSampledToken;
    /**
     * Give back the n rows a verification appended and fail the round. The
     * verification writes the attention KV only (the recurrent state is
     * committed later), so popping those rows leaves the sequence consistent.
     */
    private mtpAbortVerify;
    private disposeSampleTraceRows;
    /**
     * Throws before a bounded call of an S26 library carries more rows than it
     * was compiled for: past the bound a planned tensor overlaps its bank
     * neighbours with no error from the runtime.
     */
    private assertMtpRows;
    private assertMtpDraftLength;
    /** Positions 0..commitLen-1 for `mtp_commit`, a view of one device tensor. */
    private commitPositions;
    private disposePenaltyTensors;
    /**
     * Queue `apply_penalty_inplace` on n rows of `logits` with m (token, count)
     * entries, from views of the pipeline's penalty tensors. Their capacity is
     * the sampler rows times the context window, the most distinct tokens a
     * request can carry; a larger m reallocates once.
     */
    private applyPenalty;
    /** The sampler buffers for n verify rows, allocated on first use. */
    private mtpRowSampler;
    private mtpNewRowSampler;
    /**
     * Queue one draw per verify row with the request's sampler, the same steps
     * `sampleTokenFromLogits` takes for one row: penalties, softmax with
     * temperature, sort, top_p with the row's uniform from `rs.uniformsHost`.
     * Row i is the distribution after the drafts before it, so its penalty
     * counts include them. The ids land in `rs.ids` at the caller's sync.
     */
    private mtpQueueRowSampling;
    /** A host tensor queued to receive `t` at the next sync, outliving the scope. */
    private hostCopy;
    /**
     * One speculative round with the in-model head.
     *
     * `basePos` is the position `last` will occupy. Entering the round both the
     * main layers and the head hold 0..basePos-1, and `mtpPendingRow` is the
     * target's hidden row after basePos-1.
     *
     *  1. Draft. Each step appends one head position and projects it in the same
     *     call, so a drafted token costs one submit and one readback. The head
     *     self-chains: step i takes the drafted token's embedding and the head's
     *     own output row from step i-1, and nothing leaves the device but the id
     *     and its probability. The main layers get junk rows at those positions,
     *     which the pop below drops.
     *  2. Verify `[last, draft...]` in one `mtp_verify_head`, which writes the
     *     head's KV for the same positions from the target's own hidden rows.
     *     That is the re-prime: for every position the commit keeps, the head's
     *     companion is the target's hidden state, which is what the protocol
     *     wants (`.tmp/mtp-llamacpp-reference.md` section 2.1).
     *     Each row then yields one token: its argmax for a greedy request, or a
     *     draw with the request's sampler (`mtpQueueRowSampling`). Drafts are
     *     accepted while they equal those tokens; the first that differs, or
     *     the row after the last draft, is emitted as the target's own token.
     *     Every emitted token is an ordinary draw at its true prefix, so the
     *     output follows plain decoding's distribution for any draft.
     *  3. Commit the accepted prefix, cut at a token that ends generation, and
     *     pop the rest off both.
     *
     * @param genConfig The request's stop conditions, which cut the commit at the
     *   token that ends generation and come back as the scan to apply; null for a
     *   caller that stops by itself and takes every emitted token.
     * @param sampling The sampler the rows reproduce, null for argmax; taken
     *   from `genConfig` unless the caller (the bench) passes it.
     */
    private mtpRoundGpu;
    /** Force the speculative path off (or back on) without touching the record. */
    setMtpEnabled(enabled: boolean): void;
    /** Draft length and cutoff, for sweeping them without a reload. */
    setMtpTuning(draftLength?: number, minDraftProb?: number): void;
    /**
     * Free-running generation from raw token ids, with the speculative path
     * either on or off, and nothing of the conversation layer in the way. This
     * is the exactness gate: the two arms have to emit the same ids.
     *
     * Without a sampler both arms take the argmax. With one, both draw with it
     * from the same seed (plain sampling one uniform per token, the sampled
     * round one per emitted token), keeping penalty counts as a request would.
     *
     * @param withMargins only on the greedy non-speculative arm, where the
     *   logits are in hand: the top-1 minus top-2 logit gap at every step,
     *   which is what says whether a divergence is a near-tie.
     * @param sampler the request's sampler and seed; `expect` asks for the
     *   first emitted token that differs from it, described on its row.
     */
    benchMtpGenerate(promptTokens: Array<number>, maxNew: number, useMtp: boolean, withMargins?: boolean, sampler?: {
        config: GenerationConfig;
        seed: number;
        expect?: Array<number>;
        replay?: boolean;
        check?: number;
    } | null): Promise<{
        ids: Array<number>;
        margins: Array<number> | null;
        promptMs: number;
        decodeMs: number;
        usedMtp: boolean;
        gateReason: string | null;
        divergence: SampleDivergence | null;
        replay: SampleReplayStats | null;
        samplerCheck: SamplerCheckStats | null;
        partialFallbacks: number;
    }>;
    /**
     * Greedy id of a logits tensor plus how far ahead of the runner-up it is.
     * The device sync after the copy is not optional: without it `toArray` reads
     * whatever the cached host buffer held before, which is the previous step's
     * logits once and stale bytes the first time.
     */
    private argmaxWithMargin;
    private updateLogitsOnCPU;
    private sampleTokenFromLogits;
    /**
     * Return the an array of a mixture of token arrays and imageURLs (which cannot be represented
     * as tokens). Also return the number of tokens this represents.
     *
     * We first convert the Conversation into a prompt array to be prefilled. Then we encode the
     * text parts, leaving the imageURLs as it is.
     * Example prompts:
     * [
     *   "<|system|>\nSome system prompt\n",
     *   [
     *     "<|user|>\n",
     *     imageURL1,
     *     "\n",
     *     imageURL2,
     *     "\n",
     *     "Some user input<|end|>\n"
     *   ],
     * ]
     *
     * Expected output:
     * [
     *   token array for "<|system|>\nSome system prompt\n<|user|>\n",
     *   imageUrl1,
     *   token array for "\n",
     *   imageUrl2,
     *   token array for "\nSome user input<|end|>\n"
     */
    private getInputData;
    forwardTokensAndSample(inputIds: Array<number>, isPrefill: boolean): Promise<number>;
    /**
     * Teacher-forced input with images (docs/qwen38/S23 step 4): each image is
     * decoded from its URL and encoded exactly as a chat request does, then
     * placed before `inputIds[tokenIndex]`. A grid given with the image must
     * match the one the engine computes.
     */
    private forcedImageInput;
    /**
     * Forward the given input tokens and report the distribution of the last
     * position instead of sampling from it. Teacher-forced scoring only: no
     * logit processor, no logit bias, no penalties, no temperature.
     *
     * This function has side effects as the model will update its KV cache.
     *
     * @param inputIds The input tokens; goes through the prefill chunks when
     *   longer than one token and through the decode path when it is one token.
     * @param topK How many (id, logprob) pairs to report.
     * @param activeVocabSize The tokenizer's real vocabulary size, when it is
     *   smaller than the padded one the model emits. Nothing is masked: the
     *   log-softmax always runs over every logit, matching llama.cpp, which also
     *   normalises over the padded table. The parameter only measures how much
     *   probability the padded ids take, so a caller can see whether masking
     *   would matter. 0 disables the measurement.
     * @returns argmax, the top-K pairs sorted by descending logprob, and the
     *   number of logits the model produced.
     */
    forwardTokensAndScore(inputIds: Array<number>, topK: number, activeVocabSize?: number, images?: Array<ForcedImage>): Promise<TokenScore>;
    /**
     * The prefill-scored quality mode (docs/qwen38/S29 step 1): every position
     * of `inputIds` scored from the prefill path. Each chunk runs through
     * `batch_prefill_to_logits_and_hidden`; `score_topk` reduces blocks of its
     * hidden rows to the top-20 ids, their logits and the log-sum-exp on the
     * GPU, and the chunk's results are read back once. Side effects as a
     * prefill: the KV cache and the RNN state advance.
     *
     * @returns per position (0-based within `inputIds`) the argmax and the top
     *   (id, logprob) pairs, descending, ties to the lower id.
     */
    forwardTokensAndScorePrefill(inputIds: Array<number>, topK: number, rowsPerCall?: number): Promise<{
        positions: Array<{
            argmax: number;
            top: Array<[number, number]>;
        }>;
        chunks: number;
    }>;
    /**
     * Based on `sampledToken` and `this.logitsOnCPU`, which becomes a distribution after
     * calling `this.tvm.applySoftmaxWithTemperature()`, generate `ChatCompletionTokenLogprob` and
     * update `this.tokenLogprobArray`.
     *
     * @param sampledToken The token ID sampled.
     * @param top_logprobs Number of top tokens to include; `top_logprobs` in `ChatCompletionRequest`.
     *
     * @return The `ChatCompletionTokenLogprob` for this single autoregressive step.
     */
    private getTokenLogprob;
    /**
     * Synchronize the device.
     */
    sync(): Promise<void>;
    evaluate(): Promise<void>;
}
//# sourceMappingURL=llm_chat.d.ts.map